<?php
/**
 * Authentication API
 * Handles login, logout, and user session management
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? null;

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Create login_history table if not exists
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS login_history (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            ip_address VARCHAR(45),
            user_agent TEXT,
            device_type VARCHAR(20),
            browser VARCHAR(50),
            os VARCHAR(50),
            status VARCHAR(20) DEFAULT 'success',
            failure_reason VARCHAR(255),
            login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_id (user_id),
            INDEX idx_login_time (login_time)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    switch ($method) {
        case 'POST':
            if ($action === 'register') {
                handleRegister($pdo);
            } elseif ($action === 'logout') {
                handleLogout($pdo);
            } else {
                handleLogin($pdo);
            }
            break;
            
        case 'GET':
            if ($action === 'me') {
                handleMe($pdo);
            } elseif ($action === 'sessions') {
                handleSessions($pdo);
            } else {
                echo json_encode(['error' => 'Invalid action']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error', 'message' => $e->getMessage()]);
}

function handleLogin($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data || !isset($data['email']) || !isset($data['password'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Email and password are required']);
        return;
    }
    
    // Find user by email
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$data['email']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid email or password']);
        return;
    }
    
    // Check if account is active
    if ($user['status'] !== 'active') {
        logLoginAttempt($pdo, $user['id'], 'failed', 'Account inactive');
        http_response_code(401);
        echo json_encode(['error' => 'Account is not active. Please contact administrator.']);
        return;
    }
    
    // Verify password
    if (!password_verify($data['password'], $user['password'])) {
        logLoginAttempt($pdo, $user['id'], 'failed', 'Invalid password');
        http_response_code(401);
        echo json_encode(['error' => 'Invalid email or password']);
        return;
    }
    
    // Log successful login
    logLoginAttempt($pdo, $user['id'], 'success');
    
    // Update last login
    $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $stmt->execute([$user['id']]);
    
    // Log activity
    logActivity($pdo, $user['id'], 'login', 'auth', 'User logged in: ' . $user['email']);
    
    // Generate token (simple implementation - in production use JWT)
    $token = bin2hex(random_bytes(32));
    
    // Remove password from response
    unset($user['password']);
    
    echo json_encode([
        'success' => true,
        'user' => $user,
        'token' => $token
    ]);
}

function handleRegister($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data || !isset($data['email']) || !isset($data['password']) || !isset($data['name'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Name, email and password are required']);
        return;
    }
    
    // Check if email already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$data['email']]);
    if ($stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Email already registered']);
        return;
    }
    
    // Hash password
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // Insert user
    $stmt = $pdo->prepare("
        INSERT INTO users (name, email, password, phone, user_type, status, created_at)
        VALUES (?, ?, ?, ?, ?, 'active', NOW())
    ");
    $stmt->execute([
        $data['name'],
        $data['email'],
        $hashedPassword,
        $data['phone'] ?? null,
        $data['user_type'] ?? 'parent'
    ]);
    
    $userId = $pdo->lastInsertId();
    
    // Log activity
    logActivity($pdo, $userId, 'register', 'auth', 'New user registered: ' . $data['email']);
    
    echo json_encode([
        'success' => true,
        'message' => 'Registration successful',
        'user_id' => $userId
    ]);
}

function handleLogout($pdo) {
    // In a real implementation, you would invalidate the token
    echo json_encode(['success' => true, 'message' => 'Logged out successfully']);
}

function handleMe($pdo) {
    // In a real implementation, you would verify the token and return user data
    // For now, return an error since we don't have session management
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
}

function handleSessions($pdo) {
    $userId = $_GET['user_id'] ?? null;
    
    if (!$userId) {
        echo json_encode(['success' => true, 'sessions' => []]);
        return;
    }
    
    try {
        // Get recent login sessions from login_history
        $stmt = $pdo->prepare("
            SELECT id, device_type, browser, os, ip_address, login_time as last_active,
                   CASE WHEN login_time > DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN 1 ELSE 0 END as current
            FROM login_history 
            WHERE user_id = ? AND status = 'success'
            ORDER BY login_time DESC 
            LIMIT 10
        ");
        $stmt->execute([$userId]);
        $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format sessions
        $formattedSessions = array_map(function($s) {
            return [
                'id' => $s['id'],
                'device' => $s['browser'] . ' on ' . $s['os'],
                'location' => 'IP: ' . ($s['ip_address'] ?: 'Unknown'),
                'last_active' => $s['last_active'],
                'current' => (bool)$s['current']
            ];
        }, $sessions);
        
        echo json_encode(['success' => true, 'sessions' => $formattedSessions]);
    } catch (Exception $e) {
        echo json_encode(['success' => true, 'sessions' => []]);
    }
}

function logLoginAttempt($pdo, $userId, $status, $failureReason = null) {
    try {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
        
        // Detect device type
        $deviceType = 'unknown';
        if (preg_match('/Mobile|Android|iPhone|iPad/i', $userAgent)) {
            $deviceType = preg_match('/iPad|Tablet/i', $userAgent) ? 'tablet' : 'mobile';
        } elseif (preg_match('/Windows|Macintosh|Linux/i', $userAgent)) {
            $deviceType = 'desktop';
        }
        
        // Detect browser
        $browser = 'Unknown';
        if (preg_match('/Chrome/i', $userAgent)) $browser = 'Chrome';
        elseif (preg_match('/Firefox/i', $userAgent)) $browser = 'Firefox';
        elseif (preg_match('/Safari/i', $userAgent)) $browser = 'Safari';
        elseif (preg_match('/Edge/i', $userAgent)) $browser = 'Edge';
        
        // Detect OS
        $os = 'Unknown';
        if (preg_match('/Windows/i', $userAgent)) $os = 'Windows';
        elseif (preg_match('/Macintosh|Mac OS/i', $userAgent)) $os = 'macOS';
        elseif (preg_match('/Linux/i', $userAgent)) $os = 'Linux';
        elseif (preg_match('/Android/i', $userAgent)) $os = 'Android';
        elseif (preg_match('/iPhone|iPad/i', $userAgent)) $os = 'iOS';
        
        $stmt = $pdo->prepare("
            INSERT INTO login_history (user_id, ip_address, user_agent, device_type, browser, os, status, failure_reason, login_time)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$userId, $ipAddress, $userAgent, $deviceType, $browser, $os, $status, $failureReason]);
    } catch (Exception $e) {
        // Silently fail - don't break login if logging fails
        error_log("Login history error: " . $e->getMessage());
    }
}

function logActivity($pdo, $userId, $actionType, $module, $description) {
    try {
        // Create table if not exists
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS user_activity_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                action_type VARCHAR(50),
                module VARCHAR(50),
                description TEXT,
                ip_address VARCHAR(45),
                user_agent TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user_id (user_id),
                INDEX idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        
        $stmt = $pdo->prepare("
            INSERT INTO user_activity_logs (user_id, action_type, module, description, ip_address, user_agent, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $userId,
            $actionType,
            $module,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    } catch (Exception $e) {
        // Silently fail
        error_log("Activity log error: " . $e->getMessage());
    }
}
