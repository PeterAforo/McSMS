<?php
/**
 * System Reset API
 * Allows admin to reset the system for a new school setup
 * WARNING: This will delete ALL data except system configuration
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../../config/database.php';

// Verify admin authentication
function verifyAdmin($pdo) {
    $headers = getallheaders();
    $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;
    
    if (!$token) {
        return false;
    }
    
    // Simple token verification - in production, use proper JWT verification
    $stmt = $pdo->prepare("SELECT id, user_type FROM users WHERE id = ? AND user_type = 'admin' AND status = 'active'");
    
    // Decode token to get user ID (assuming token contains user_id)
    $tokenParts = explode('.', $token);
    if (count($tokenParts) >= 2) {
        $payload = json_decode(base64_decode($tokenParts[1]), true);
        if (isset($payload['user_id'])) {
            $stmt->execute([$payload['user_id']]);
            return $stmt->fetch() !== false;
        }
    }
    
    return false;
}

// Get list of tables that will be affected
function getResetPreview($pdo) {
    $tables = [
        'students' => 'Student records',
        'teachers' => 'Teacher records',
        'parents' => 'Parent records',
        'classes' => 'Class definitions',
        'sections' => 'Class sections',
        'subjects' => 'Subject definitions',
        'grades' => 'Student grades',
        'attendance' => 'Attendance records',
        'employee_attendance' => 'Employee attendance',
        'exams' => 'Exam definitions',
        'exam_results' => 'Exam results',
        'assignments' => 'Assignments',
        'homework' => 'Homework',
        'invoices' => 'Fee invoices',
        'payments' => 'Payment records',
        'fee_groups' => 'Fee groups',
        'fee_items' => 'Fee items',
        'fee_rules' => 'Fee rules',
        'timetable_entries' => 'Timetable entries',
        'leave_applications' => 'Leave applications',
        'payroll' => 'Payroll records',
        'messages' => 'Messages',
        'notifications' => 'Notifications',
        'activity_logs' => 'Activity logs',
    ];
    
    $preview = [];
    
    foreach ($tables as $table => $description) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM `$table`");
            $result = $stmt->fetch();
            $preview[] = [
                'table' => $table,
                'description' => $description,
                'record_count' => (int)$result['count']
            ];
        } catch (PDOException $e) {
            // Table doesn't exist, skip it
            continue;
        }
    }
    
    return $preview;
}

// Perform the system reset
function performReset($pdo, $options) {
    $resetLog = [];
    $errors = [];
    
    // Tables to reset in order (respecting foreign key constraints)
    $resetOrder = [
        // First, tables with no dependencies or only outgoing references
        'activity_logs',
        'notifications',
        'messages',
        'grades',
        'exam_results',
        'attendance',
        'employee_attendance',
        'homework',
        'assignments',
        'payments',
        'invoices',
        'payroll',
        'leave_applications',
        'timetable_entries',
        // Then tables with some dependencies
        'students',
        'teachers',
        'parents',
        'exams',
        'fee_rules',
        'fee_items',
        'fee_groups',
        'sections',
        'subjects',
        'classes',
    ];
    
    // Tables to preserve (system configuration)
    $preserveTables = [
        'users', // Will handle separately - only delete non-admin users
        'system_settings',
        'school_settings',
        'roles',
        'permissions',
        'role_permissions',
        'terms', // Academic terms - optionally reset
        'academic_years',
    ];
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // Disable foreign key checks temporarily
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        
        // Reset each table
        foreach ($resetOrder as $table) {
            try {
                $stmt = $pdo->query("SELECT COUNT(*) as count FROM `$table`");
                $beforeCount = $stmt->fetch()['count'];
                
                if ($beforeCount > 0) {
                    $pdo->exec("TRUNCATE TABLE `$table`");
                    $resetLog[] = [
                        'table' => $table,
                        'records_deleted' => (int)$beforeCount,
                        'status' => 'success'
                    ];
                }
            } catch (PDOException $e) {
                // Table doesn't exist or other error
                $errors[] = [
                    'table' => $table,
                    'error' => $e->getMessage()
                ];
            }
        }
        
        // Handle users table - delete non-admin users only
        if (!isset($options['keep_all_users']) || !$options['keep_all_users']) {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE user_type != 'admin'");
            $userCount = $stmt->fetch()['count'];
            
            $pdo->exec("DELETE FROM users WHERE user_type != 'admin'");
            $resetLog[] = [
                'table' => 'users (non-admin)',
                'records_deleted' => (int)$userCount,
                'status' => 'success'
            ];
        }
        
        // Optionally reset terms
        if (isset($options['reset_terms']) && $options['reset_terms']) {
            try {
                $stmt = $pdo->query("SELECT COUNT(*) as count FROM terms");
                $termCount = $stmt->fetch()['count'];
                $pdo->exec("TRUNCATE TABLE terms");
                $resetLog[] = [
                    'table' => 'terms',
                    'records_deleted' => (int)$termCount,
                    'status' => 'success'
                ];
            } catch (PDOException $e) {
                $errors[] = ['table' => 'terms', 'error' => $e->getMessage()];
            }
        }
        
        // Optionally reset academic years
        if (isset($options['reset_academic_years']) && $options['reset_academic_years']) {
            try {
                $stmt = $pdo->query("SELECT COUNT(*) as count FROM academic_years");
                $yearCount = $stmt->fetch()['count'];
                $pdo->exec("TRUNCATE TABLE academic_years");
                $resetLog[] = [
                    'table' => 'academic_years',
                    'records_deleted' => (int)$yearCount,
                    'status' => 'success'
                ];
            } catch (PDOException $e) {
                $errors[] = ['table' => 'academic_years', 'error' => $e->getMessage()];
            }
        }
        
        // Clear uploaded files if requested
        if (isset($options['clear_uploads']) && $options['clear_uploads']) {
            $uploadDirs = [
                $_SERVER['DOCUMENT_ROOT'] . '/uploads/',
                __DIR__ . '/../../public/uploads/',
            ];
            
            foreach ($uploadDirs as $dir) {
                if (is_dir($dir)) {
                    $files = glob($dir . '*');
                    $deletedCount = 0;
                    foreach ($files as $file) {
                        if (is_file($file) && basename($file) !== '.htaccess') {
                            unlink($file);
                            $deletedCount++;
                        }
                    }
                    if ($deletedCount > 0) {
                        $resetLog[] = [
                            'table' => 'uploads',
                            'records_deleted' => $deletedCount,
                            'status' => 'success',
                            'note' => 'Files deleted from ' . $dir
                        ];
                    }
                }
            }
            
            // Clear logo URL from settings
            try {
                $pdo->exec("UPDATE system_settings SET setting_value = '' WHERE setting_key = 'school_logo'");
            } catch (PDOException $e) {
                // Ignore if table doesn't exist
            }
        }
        
        // Re-enable foreign key checks
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        
        // Commit transaction
        $pdo->commit();
        
        // Log the reset action
        try {
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action, description, ip_address, created_at)
                VALUES (?, 'system_reset', ?, ?, NOW())
            ");
            $stmt->execute([
                $options['admin_user_id'] ?? 1,
                'System reset performed. Tables affected: ' . count($resetLog),
                $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ]);
        } catch (PDOException $e) {
            // Activity log table might not exist
        }
        
        return [
            'success' => true,
            'message' => 'System reset completed successfully',
            'reset_log' => $resetLog,
            'errors' => $errors,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        
        return [
            'success' => false,
            'error' => 'Reset failed: ' . $e->getMessage(),
            'reset_log' => $resetLog,
            'errors' => $errors
        ];
    }
}

// Main request handling
try {
    $method = $_SERVER['REQUEST_METHOD'];
    
    // GET - Preview what will be reset
    if ($method === 'GET') {
        $action = $_GET['action'] ?? 'preview';
        
        if ($action === 'preview') {
            $preview = getResetPreview($pdo);
            $totalRecords = array_sum(array_column($preview, 'record_count'));
            
            echo json_encode([
                'success' => true,
                'preview' => $preview,
                'total_records' => $totalRecords,
                'warning' => 'This action will permanently delete all data listed above. This cannot be undone!',
                'preserved' => [
                    'Admin user accounts',
                    'Roles (admin, teacher, parent, etc.)',
                    'Permissions and role assignments',
                    'System settings',
                    'School settings (name, logo, etc.)'
                ]
            ]);
        } else {
            throw new Exception('Invalid action');
        }
    }
    
    // POST - Perform the reset
    elseif ($method === 'POST') {
        // Verify admin authentication
        if (!verifyAdmin($pdo)) {
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'error' => 'Unauthorized. Only administrators can perform system reset.'
            ]);
            exit();
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        // Require confirmation code
        $confirmCode = $input['confirmation_code'] ?? '';
        if ($confirmCode !== 'RESET-CONFIRM') {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => 'Invalid confirmation code. Please enter "RESET-CONFIRM" to proceed.'
            ]);
            exit();
        }
        
        // Get options
        $options = [
            'keep_all_users' => $input['keep_all_users'] ?? false,
            'reset_terms' => $input['reset_terms'] ?? false,
            'reset_academic_years' => $input['reset_academic_years'] ?? false,
            'clear_uploads' => $input['clear_uploads'] ?? true,
            'admin_user_id' => $input['admin_user_id'] ?? 1
        ];
        
        $result = performReset($pdo, $options);
        
        if ($result['success']) {
            echo json_encode($result);
        } else {
            http_response_code(500);
            echo json_encode($result);
        }
    }
    
    else {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
